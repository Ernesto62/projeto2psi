<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Musico;


class MusicosController extends Controller
{
     
 public function index(){
 	$musicos = Musico::paginate(6);
   	return view('musicos.index', ['musicos'=>$musicos]);
}

public function show (Request $request){
	$idMusico=$request->id;
	$musico=Musico::where('id_musico', $idMusico)->with('musicas')->first();
	return view('musicos.show',  ['musico'=>$musico]);
}
public function create (){
	return view('musicos.create');
}
public function store(Request $request){
	$novoMusico = $request->validate ([
		
         'nome'=>['nullable', 'min:3', 'max:100'],
         'nacionalidade'=>['nullable', 'min:3', 'max:100'],
         'data_nascimento'=>['nullable', 'min:3', 'max:100'],
         'fotografia'=>['nullable', 'min:3', 'max:100']

         

	]);
	$musico = Musico::create($novoMusico);

	return redirect()->route('musicos.show',['id'=>$musico->id_musico]);
}
public function update (Request $request) {
			$idMusico = $request->id;
			$musico = Musico::findOrFail($idMusico);
			$atualizarMusico = $request->validate([

    'nome'=>['nullable', 'min:3', 'max:100'],
         'nacionalidade'=>['nullable', 'min:3', 'max:100'],
         'data_nascimento'=>['nullable', 'min:3', 'max:100'],
         'fotografia'=>['nullable', 'min:3', 'max:100']
     
         
]);
	$musico->update($atualizarMusico);
	return redirect()->route('musicos.show', ['id'=>$musico->id_musico
]);
}

	public function edit (Request $request){
   $idMusico=$request->id;

 

   $musico=Musico::where('id_musico',$idMusico)->first();
  
   

   return view('musicos.edit',[
      'musico'=>$musico
     
     
     
]);




}
public function delete(Request $request){
	  $idMusico=$request->id;
   $musico=Musico::where('id_musico',$idMusico)->first();
   
   return view ('musicos.delete',['musico'=>$musico]);
   
}
public function destroy (Request $request){
   $idMusico=$request->id;


   $musico=Musico::findOrFail($idMusico);


  

   $musico->delete();


   return redirect()->route('generos.index');
}
}
