<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Musica;


class MusicasController extends Controller
{
       	public function index(){
 			$musicas = Musica::paginate(6);
   			return view('musicas.index', ['musicas'=>$musicas]);
		}

		public function show (Request $request){
			$idMusica=$request->id;
			$musica=Musica::where('id_musica',$idMusica)->with('musicos')->first();
			return view('musicas.show',  ['musica'=>$musica]);
		}

		public function create (){
			return view('musicas.create');
		}

		public function store(Request $request){
			$novoMusica = $request->validate ([
		
         	'titulo'=>['nullable', 'min:3', 'max:100'],
         	'id_musico'=>['nullable', 'min:3', 'max:100'],
         	'id_genero'=>['nullable', 'min:3', 'max:100']
			]);

			$musica = Musica::create($novoMusica);

			return redirect()->route('musicas.show',['id'=>$musica->id_musica]);
		}

		public function update (Request $request) {
			$idMusica = $request->id;
			$musica = Musica::findOrFail($idMusica);
			$atualizarMusica = $request->validate([

    'titulo'=>['nullable', 'min:3', 'max:100'],
         'id_musico'=>['nullable', 'min:3', 'max:100'],
         'id_genero'=>['nullable', 'min:3', 'max:100']
         
]);
	$musica->update($atualizarMusica);
	return redirect()->route('musicas.show', ['id'=>$musica->id_musica
]);
}

	public function edit (Request $request){
   $idMusica=$request->id;

 

   $musica=Musica::where('id_musica',$idMusica)->first();
  
   

   return view('musicas.edit',[
      'musica'=>$musica
     
     
     
]);




}
public function delete(Request $request){
	  $idMusica=$request->id;
   $musica=Musica::where('id_musica',$idMusica)->first();
   
   return view ('musicas.delete',['musica'=>$musica]);
   
}
public function destroy (Request $request){
   $idMusica=$request->id;


   $musica=Musica::findOrFail($idMusica);


  

   $musica->delete();


   return redirect()->route('musicas.index');
}
}

