<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Album;


class AlbunsController extends Controller
{

 public function index(){
     $albuns = Album::paginate(6);
       return view('albuns.index', ['albuns'=>$albuns]);

}

public function show (Request $request){
    $idAlbum=$request->id;
    $album=Album::where('id_album', $idAlbum)->with('musicas')->first();
    return view('albuns.show',  ['album'=>$album]);
}
public function create (){
	return view('albuns.create');
}
public function store(Request $request){
	$novoAlbum = $request->validate ([
		
         'titulo'=>['nullable', 'min:3', 'max:100'],
         'id_genero'=>['nullable', 'min:3', 'max:100'],
         'id_musico'=>['nullable', 'min:3', 'max:100'],
         'data_lancamento'=>['nullable', 'min:3', 'max:100'],
         'observacoes'=>['nullable', 'min:3', 'max:100']
         
         

	]);
	$album = Album::create($novoAlbum);

	return redirect()->route('albuns.show',['id'=>$album->id_album]);
}
public function update (Request $request) {
            $idAlbum = $request->id;
            $album = Album::findOrFail($idAlbum);
            $atualizarAlbum = $request->validate([

    'nome'=>['nullable', 'min:3', 'max:100'],
         'nacionalidade'=>['nullable', 'min:3', 'max:100'],
         'data_nascimento'=>['nullable', 'min:3', 'max:100'],
         'fotografia'=>['nullable', 'min:3', 'max:100']
     
         
]);
    $album->update($atualizarAlbum);
    return redirect()->route('albuns.show', ['id'=>$album->id_album
]);
}

    public function edit (Request $request){
   $idAlbum=$request->id;

 

   $album=Album::where('id_album',$idAlbum)->first();
  
   

   return view('albuns.edit',[
      'album'=>$album
     
     
     
]);




}
public function delete(Request $request){
    $idAlbum=$request->id;
   $album=Album::where('id_album',$idAlbum)->first();
   
   return view ('albuns.delete',['album'=>$album]);
   
}
public function destroy (Request $request){
   $idAlbum=$request->id;


   $album=Album::findOrFail($idAlbum);


  

   $album->delete();


   return redirect()->route('albuns.index');
}
}