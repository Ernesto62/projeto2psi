<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('generos.update',['id'=>$genero->id_genero])}}" method="post">

@csrf
@method('patch')

designacao: <input type="text" name="designacao" value=""><br><br>

	observacoes: <input type="text" name="observacoes" value=""><br><br>

		


<input type="submit" value="Enviar!">
</form>
</body>
</html>