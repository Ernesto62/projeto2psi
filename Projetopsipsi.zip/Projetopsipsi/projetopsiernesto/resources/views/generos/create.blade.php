<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('generos.store')}}" method="post">
@csrf


designacao:  <input type="text" name="designacao"value="{{old('designacao')}}"><br>

observacoes:  <input type="text" name="observacoes" value="{{old('observacoes')}}"><br>




<input type="submit" value="Enviar">
</form>



</body>
</html>