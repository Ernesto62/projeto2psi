@extends('layout')
@section('titulo-pagina')

@endsection
@section('header')

@endsection
@section('conteudo')
<ul>
@foreach($musicas as $musica)
<h3>
<a  href="{{route('musicas.show', ['id'=>$musica->id_musica])}}">
	{{$musica->titulo}}</a></h3>
	
@endforeach
<a href="{{route('musicas.create', ['id'=>$musica->id_musica])}}">Criar</a>
<br>
<img  src="musica.gif" alt="some text" width=400 height=300 align="center">
</ul>
{{$musicas->render()}}
</div>
@endsection
