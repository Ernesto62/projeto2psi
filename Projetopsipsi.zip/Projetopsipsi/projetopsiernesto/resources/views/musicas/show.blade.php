
<i>ID-{{$musica->id_musica}}</i><br>
<i>Titulo-{{$musica->titulo}}</i><br>
<i>ID Musico-{{$musica->id_musico}}</i><br>
<i>ID Genero-{{$musica->id_genero}}</i><br>

<br>
<h5>Musico:</h5>

@foreach($musica->musicos as $musico)
<i>{{$musico->nome}}</i>
@endforeach


<a href="{{route('musicas.edit', ['id'=>$musica->id_musica])}}"><h4>Editar</h4></a>

<a href="{{route('musicas.delete', ['id'=>$musica->id_musica])}}">Eliminar</a>

                    
               


