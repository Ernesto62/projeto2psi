<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('musicas.update',['id'=>$musica->id_musica])}}" method="post">

@csrf
@method('patch')

titulo: <input type="text" name="titulo" value=""><br><br>

	id_musico: <input type="text" name="id_musico" value=""><br><br>

		id_genero: <input type="text" name="id_genero" value=""><br><br>



<input type="submit" value="Enviar!">
</form>
</body>
</html>