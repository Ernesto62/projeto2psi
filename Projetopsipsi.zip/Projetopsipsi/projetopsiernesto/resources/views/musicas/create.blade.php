<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('musicas.store')}}" method="post">
@csrf


titulo:  <input type="text" name="titulo"value="{{old('titulo')}}"><br>

id_musico:  <input type="text" name="id_musico" value="{{old('id_musico')}}"><br>

id_genero:  <input type="text" name="id_genero" value="{{old('id_genero')}}"><br>


<input type="submit" value="Enviar">
</form>



</body>
</html>
