<i>ID-{{$album->id_album}}</i><br>
<i>Titulo-{{$album->titulo}}</i><br>
<i>Data lançamento-{{$album->data_lancamento}}</i><br>
<i>Observacoes-{{$album->observacoes}}</i><br>
<br>

<h5><u>Musicas:</u></h5>

@foreach($album->musicas as $musica)
<i>{{$musica->titulo}}</i>
@endforeach

<a href="{{route('albuns.edit', ['id'=>$album->id_album])}}"><h4>Editar</h4></a>

<a href="{{route('albuns.delete', ['id'=>$album->id_album])}}">Eliminar</a>

