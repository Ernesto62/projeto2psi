<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('albuns.store')}}" method="post">
@csrf


	titulo:  <input type="text" name="titulo"value="{{old('titulo')}}"><br>

id_genero:  <input type="text" name="id_genero" value="{{old('id_genero')}}"><br>

	id_musico:  <input type="text" name="id_musico"value="{{old('id_musico')}}"><br>

data_lancamento:  <input type="text" name="data_lancamento" value="{{old('data_lancamento')}}"><br>

	observacoes:  <input type="text" name="observacoes"value="{{old('observacoes')}}"><br>






<input type="submit" value="Enviar">
</form>



</body>
</html>