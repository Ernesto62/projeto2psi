<h2>Deseja eliminar</h2>
<h2>{{$album->titulo}}</h2>
<form method="post" action="{{route('albuns.destroy',['id'=>$album->id_album])}}">
	@csrf 
	@method('delete')
	<input type="submit" name="enviar">
</form>

@if(session()->has('mensagem'))
<div class="alert alert-danger" role="alert">{{session('mensagem')}}
	{{session('mensagem')}}
	@endif