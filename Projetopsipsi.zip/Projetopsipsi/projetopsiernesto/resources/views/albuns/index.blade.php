@extends('layout')
@section('titulo-pagina')

@endsection
@section('header')

@endsection
@section('conteudo')
<ul>
@foreach($albuns as $album)
<h3>
<a  href="{{route('albuns.show', ['id'=>$album->id_album])}}">

{{$album->titulo}}</a></h3>

@endforeach
<a href="{{route('albuns.create', ['id'=>$album->id_album])}}">Criar</a>
<br>
<img  src="musica.gif" alt="some text" width=400 height=300 align="center">
</ul>
{{$albuns->render()}}
</div>
@endsection