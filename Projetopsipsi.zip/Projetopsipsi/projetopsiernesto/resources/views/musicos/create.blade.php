<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('musicos.store')}}" method="post">
@csrf


nome:  <input type="text" name="nome"value="{{old('nome')}}"><br>

nacionalidade:  <input type="text" name="nacionalidade" value="{{old('nacionalidade')}}"><br>

data_nascimento:  <input type="text" name="data_nascimento"value="{{old('data_nascimento')}}"><br>

fotografia:  <input type="text" name="fotografia" value="{{old('fotografia')}}"><br>



<input type="submit" value="Enviar">
</form>



</body>
</html>