@extends('layout')
@section('titulo-pagina')

@endsection
@section('header')

@endsection
@section('conteudo')
<ul>
@foreach($musicos as $musico)
<h3>
<a  href="{{route('musicos.show', ['id'=>$musico->id_musico])}}">

{{$musico->nome}}</a></h3>

@endforeach

<a href="{{route('musicos.create', ['id'=>$musico->id_musico])}}">Criar</a>
<br>

<img  src="musica.gif" alt="some text" width=400 height=300 align="center">
</ul>
{{$musicos->render()}}
</div>
@endsection
