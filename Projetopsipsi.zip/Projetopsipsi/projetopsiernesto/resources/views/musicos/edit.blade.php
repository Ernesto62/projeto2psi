<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="{{route('musicos.update',['id'=>$musico->id_musico])}}" method="post">

@csrf
@method('patch')

	nome: <input type="text" name="nome" value=""><br><br>

	nacionalidade: <input type="text" name="nacionalidade" value=""><br><br>

		data_nascimento	: <input type="text" name="data_nascimento	" value=""><br><br>

			fotografia	: <input type="text" name="	fotografia	" value=""><br><br>




<input type="submit" value="Enviar!">
</form>
</body>
</html>