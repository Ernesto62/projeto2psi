
<i>ID-{{$musico->id_musico}}</i><br>
<i>Nome-{{$musico->nome}}</i><br>
<i>Nacionalidade-{{$musico->nacionalidade}}</i><br>
<i >Data Nascimento-{{$musico->data_nascimento}}</i><br>
<br>

<h5>Musicas:</h5>

@foreach($musico->musicas as $musica)
<i>{{$musica->titulo}}</i>
@endforeach
<a href="{{route('musicos.edit', ['id'=>$musico->id_musico])}}"><h4>Editar</h4></a>

<a href="{{route('musicos.delete', ['id'=>$musico->id_musico])}}">Eliminar</a>