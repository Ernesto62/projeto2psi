
<?php $__env->startSection('titulo-pagina'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menupr'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

<div align="center">
<ul>
<?php $__currentLoopData = $musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>
<a class="btn btn-primary" role="button" href="<?php echo e(route('musicas.show', ['id'=>$musica->id_musica])); ?>">
	<?php echo e($musica->titulo); ?></a></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($musicas->render()); ?>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('galeria'); ?>
@endesection

<?php $__env->startSection('rodape'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\Desktop\PSI-Projeto\resources\views/musicas/index.blade.php ENDPATH**/ ?>