<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('albuns.update',['id'=>$album->id_album])); ?>" method="post">

<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

	titulo: <input type="text" name="titulo" value=""><br><br>

	id_genero: <input type="text" name="id_genero" value=""><br><br>

		id_musico	: <input type="text" name="id_musico	" value=""><br><br>

			data_lancamento	: <input type="text" name="	data_lancamento	" value=""><br><br>

			observacoes	: <input type="text" name="	observacoes	" value=""><br><br>




<input type="submit" value="Enviar!">
</form>
</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/albuns/edit.blade.php ENDPATH**/ ?>