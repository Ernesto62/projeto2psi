<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('musicas.update',['id'=>$musica->id_musica])); ?>" method="post">

<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

titulo: <input type="text" name="titulo" value=""><br><br>

	id_musico: <input type="text" name="id_musico" value=""><br><br>

		id_genero: <input type="text" name="id_genero" value=""><br><br>



<input type="submit" value="Enviar!">
</form>
</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/musicas/edit.blade.php ENDPATH**/ ?>