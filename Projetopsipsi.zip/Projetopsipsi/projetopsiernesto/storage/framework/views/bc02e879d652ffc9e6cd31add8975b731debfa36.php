<h2>Deseja eliminar</h2>
<h2><?php echo e($album->titulo); ?></h2>
<form method="post" action="<?php echo e(route('albuns.destroy',['id'=>$album->id_album])); ?>">
	<?php echo csrf_field(); ?> 
	<?php echo method_field('delete'); ?>
	<input type="submit" name="enviar">
</form>

<?php if(session()->has('mensagem')): ?>
<div class="alert alert-danger" role="alert"><?php echo e(session('mensagem')); ?>

	<?php echo e(session('mensagem')); ?>

	<?php endif; ?><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/albuns/delete.blade.php ENDPATH**/ ?>