<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('albuns.store')); ?>" method="post">
<?php echo csrf_field(); ?>


	titulo:  <input type="text" name="titulo"value="<?php echo e(old('titulo')); ?>"><br>

id_genero:  <input type="text" name="id_genero" value="<?php echo e(old('id_genero')); ?>"><br>

	id_musico:  <input type="text" name="id_musico"value="<?php echo e(old('id_musico')); ?>"><br>

data_lancamento:  <input type="text" name="data_lancamento" value="<?php echo e(old('data_lancamento')); ?>"><br>

	observacoes:  <input type="text" name="observacoes"value="<?php echo e(old('observacoes')); ?>"><br>






<input type="submit" value="Enviar">
</form>



</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/albuns/create.blade.php ENDPATH**/ ?>