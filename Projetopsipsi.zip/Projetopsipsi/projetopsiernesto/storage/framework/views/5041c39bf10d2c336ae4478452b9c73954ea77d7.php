<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('generos.update',['id'=>$genero->id_genero])); ?>" method="post">

<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

designacao: <input type="text" name="designacao" value=""><br><br>

	observacoes: <input type="text" name="observacoes" value=""><br><br>

		


<input type="submit" value="Enviar!">
</form>
</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/generos/edit.blade.php ENDPATH**/ ?>