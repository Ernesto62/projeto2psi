
<i>ID-<?php echo e($musica->id_musica); ?></i><br>
<i>Titulo-<?php echo e($musica->titulo); ?></i><br>
<i>ID Musico-<?php echo e($musica->id_musico); ?></i><br>
<i>ID Genero-<?php echo e($musica->id_genero); ?></i><br>

<br>
<h5>Musico:</h5>

<?php $__currentLoopData = $musica->musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i><?php echo e($musico->nome); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH D:\ProjetoPsi\projetopsiernesto\resources\views/musicas/show.blade.php ENDPATH**/ ?>