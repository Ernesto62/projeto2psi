
<i>ID Genero-<?php echo e($genero->id_genero); ?></i><br>
<i>Designação-<?php echo e($genero->designacao); ?></i><br>
<i>Observações-<?php echo e($genero->observacoes); ?></i><br>
<br>
<h5><u>Musicas:</u></h5>

<?php $__currentLoopData = $genero->musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i ><?php echo e($musica->titulo); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<a href="<?php echo e(route('generos.edit', ['id'=>$genero->id_genero])); ?>"><h4>Editar</h4></a>

<a href="<?php echo e(route('generos.delete', ['id'=>$genero->id_genero])); ?>">Eliminar</a>
<?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/generos/show.blade.php ENDPATH**/ ?>