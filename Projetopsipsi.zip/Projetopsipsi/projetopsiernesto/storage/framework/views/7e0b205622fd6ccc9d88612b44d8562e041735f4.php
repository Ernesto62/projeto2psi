<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('generos.store')); ?>" method="post">
<?php echo csrf_field(); ?>


designacao:  <input type="text" name="designacao"value="<?php echo e(old('designacao')); ?>"><br>

observacoes:  <input type="text" name="observacoes" value="<?php echo e(old('observacoes')); ?>"><br>




<input type="submit" value="Enviar">
</form>



</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/generos/create.blade.php ENDPATH**/ ?>