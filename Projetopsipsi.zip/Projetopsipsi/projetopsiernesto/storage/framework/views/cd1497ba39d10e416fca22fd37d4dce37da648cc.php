
<ul>
<?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3>
<a href="<?php echo e(route('generos.show', ['id'=>$genero->id_genero])); ?>">
<?php echo e($genero->designacao); ?></a></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($generos->render()); ?>

</div>

<?php /**PATH D:\ProjetoPsi\projetopsiernesto\resources\views/generos/index.blade.php ENDPATH**/ ?>