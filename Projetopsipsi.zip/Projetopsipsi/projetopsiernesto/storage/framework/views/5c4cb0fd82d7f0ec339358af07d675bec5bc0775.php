<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('musicos.store')); ?>" method="post">
<?php echo csrf_field(); ?>


nome:  <input type="text" name="nome"value="<?php echo e(old('nome')); ?>"><br>

nacionalidade:  <input type="text" name="nacionalidade" value="<?php echo e(old('nacionalidade')); ?>"><br>

data_nascimento:  <input type="text" name="data_nascimento"value="<?php echo e(old('data_nascimento')); ?>"><br>

fotografia:  <input type="text" name="fotografia" value="<?php echo e(old('fotografia')); ?>"><br>



<input type="submit" value="Enviar">
</form>



</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/musicos/create.blade.php ENDPATH**/ ?>