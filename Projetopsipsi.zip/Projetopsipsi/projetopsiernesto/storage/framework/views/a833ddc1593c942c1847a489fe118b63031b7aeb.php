<i>ID-<?php echo e($album->id_album); ?></i><br>
<i>Titulo-<?php echo e($album->titulo); ?></i><br>
<i>Data lançamento-<?php echo e($album->data_lancamento); ?></i><br>
<i>Observacoes-<?php echo e($album->observacoes); ?></i><br>
<br>

<h5><u>Musicas:</u></h5>

<?php $__currentLoopData = $album->musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i><?php echo e($musica->titulo); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<a href="<?php echo e(route('albuns.edit', ['id'=>$album->id_album])); ?>"><h4>Editar</h4></a>

<a href="<?php echo e(route('albuns.delete', ['id'=>$album->id_album])); ?>">Eliminar</a>

<?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/albuns/show.blade.php ENDPATH**/ ?>