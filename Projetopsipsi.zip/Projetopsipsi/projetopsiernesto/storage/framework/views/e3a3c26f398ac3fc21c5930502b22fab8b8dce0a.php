<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="<?php echo e(route('musicos.update',['id'=>$musico->id_musico])); ?>" method="post">

<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>

	nome: <input type="text" name="nome" value=""><br><br>

	nacionalidade: <input type="text" name="nacionalidade" value=""><br><br>

		data_nascimento	: <input type="text" name="data_nascimento	" value=""><br><br>

			fotografia	: <input type="text" name="	fotografia	" value=""><br><br>




<input type="submit" value="Enviar!">
</form>
</body>
</html><?php /**PATH C:\Projetopsipsi\projetopsiernesto\resources\views/musicos/edit.blade.php ENDPATH**/ ?>