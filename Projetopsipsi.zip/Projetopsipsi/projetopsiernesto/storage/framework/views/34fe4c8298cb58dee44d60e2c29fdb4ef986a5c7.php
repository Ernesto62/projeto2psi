
<?php $__env->startSection('titulo-pagina'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menupr'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
<div align="center">
<i style="color: blue">ID:</i>  <i style="color: white"><?php echo e($musica->id_musica); ?></i><br>
<i style="color: blue">Titulo:</i>  <i style="color: white"><?php echo e($musica->titulo); ?></i><br>
<i style="color: blue">ID Musico:</i>  <i style="color: white"><?php echo e($musica->id_musico); ?></i><br>
<i style="color: blue">ID Genero:</i>  <i style="color: white"><?php echo e($musica->id_genero); ?></i><br>

<br>
<h5 style="color: blue"><u>Genero:</u></h5>

<?php $__currentLoopData = $musica->generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i style="color: white"><?php echo e($genero->designacao); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<h5 style="color: blue"><u>Musico:</u></h5>

<?php $__currentLoopData = $musica->musicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i style="color: white"><?php echo e($musico->nome); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('galeria'); ?>
@endesection

<?php $__env->startSection('rodape'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\Desktop\PSI-Projeto\resources\views/musicas/show.blade.php ENDPATH**/ ?>