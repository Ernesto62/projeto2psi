
<div align="center">
<i>ID:<?php echo e($musico->id_musico); ?></i><br>
<i> Nome:<?php echo e($musico->nome); ?></i><br>
<i>Nacionalidade:<?php echo e($musico->nacionalidade); ?></i><br>
<i >Data Nascimento:<?php echo e($musico->data_nascimento); ?></i><br>
<br>

<h5>Musicas:</h5>

<?php $__currentLoopData = $musico->musicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $musica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i><?php echo e($musica->titulo); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>
<h5 ><u>Albuns:</u></h5>
<?php $__currentLoopData = $musico->albuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<i><?php echo e($album->titulo); ?></i>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\Users\anton\Desktop\projeto-psi-ernesto\resources\views/musicos/show.blade.php ENDPATH**/ ?>