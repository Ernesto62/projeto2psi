<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('titulo-pagina'); ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">

  </head>
  <body>
    <?php echo $__env->yieldContent('header'); ?>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <a class="navbar-brand" >Er_Musicas</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                
                <li class="nav-item">
                    <a class="nav-link" href="musicas">Musicas</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="generos">Generos</a>
                    
                </li>
                
                <li class="nav-item">
                    <a class="nav-link desable" href="musicos">Musicos</a>
                    
                </li>
                 <li class="nav-item">
                    <a class="nav-link desable" href="albuns">Albuns</a>
                    
                </li>


            </ul>
        </div>
        
    </nav>
    <main role="main">
         <br>
        <br>
        <br>
        <br>
              
        <?php echo $__env->yieldContent('conteudo'); ?>          
        <br>
        <br>
        <br>
        
    <footer class="container"><p>&copy;Companhia 12ºI2 2020-2021</p></footer>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>
<?php /**PATH F:\ProjetoPsi\projetopsiernesto\resources\views/layout.blade.php ENDPATH**/ ?>